package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class DataController {
	
	
	@Value("${message-Developer}")
	private String message1;
	
	@Value("${message-Testing}")
	private String message2;
	
	@Value("${message-Default}")
	private String message3;

	@GetMapping("Developer")
	public String msg1() {
		return "Hi this is the message - "+message1+" .";
	}
	
	@GetMapping("Testing")
	public String msg2() {
		return "Hi this is the message - "+message2+" .";
	}
	
	@GetMapping("Default")
	public String msg3() {
		return "Hi this is the message - "+message3+" .";
	}
}
